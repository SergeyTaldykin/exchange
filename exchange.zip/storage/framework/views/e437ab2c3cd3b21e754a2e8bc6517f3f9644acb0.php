<?php $__env->startSection('title', 'Page Title333'); ?>

<?php $__env->startSection('body'); ?>
    ##parent-placeholder-02083f4579e08a612425c0c1a17ee47add783b94##

    <section class="site-section bg-light" id="contact-section" data-aos="fade">
        <div class="container">
            <div class="row mb-5">
                <div class="col-12 text-center">
                    <h2 class="section-title mb-3"><?php echo app('translator')->get('Registration'); ?></h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 mb-5">
                    <form method="post" class="p-5 bg-white">
                        <?php echo csrf_field(); ?>
                        <h2 class="h4 text-black mb-5">Contact Form</h2>

                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <div class="row form-group">
                            <div class="col-md-6 mb-3 mb-md-0">
                                <label class="text-black" for="name"><?php echo app('translator')->get('Name'); ?></label>
                                <input name="name" id="name" class="form-control" value="<?php echo e(old('name')); ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="text-black" for="email"><?php echo app('translator')->get('Email'); ?></label>
                                <input name="email" id="email" class="form-control" value="<?php echo e(old('email')); ?>">
                            </div>
                        </div>

                        <div class="row form-group">
                            <div class="col-md-12">
                                <label class="text-black" for="password"><?php echo app('translator')->get('Password'); ?></label>
                                <input name="password" id="password" type="password" class="form-control">
                            </div>
                        </div>

                        <div class="row form-group">
                            <div class="col-md-12">
                                <label class="text-black" for="password_confirmation"><?php echo app('translator')->get('Password confirmation'); ?></label>
                                <input name="password_confirmation" id="password_confirmation" type="password" class="form-control">
                            </div>
                        </div>

                        <div class="row form-group">
                            <div class="col-md-12">
                                <input type="submit" value="Send Message" class="btn btn-primary btn-md text-white">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/exchange/resources/views/auth/register.blade.php ENDPATH**/ ?>
<?php

namespace App\Http\Controllers;

class ContactUsController extends Controller
{
    public function store(ContactUsRequest $request)
    {

    }
}
